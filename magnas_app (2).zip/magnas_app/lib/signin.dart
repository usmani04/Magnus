import 'package:flutter/material.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:magnas_app/Dashboard.dart';
import 'package:magnas_app/forgot.dart';
import 'package:magnas_app/signup.dart';

class Signin extends StatefulWidget {
  const Signin({Key? key}) : super(key: key);

  @override
  State<Signin> createState() => _SigninState();
}

class _SigninState extends State<Signin> {
  bool status = false;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: Colors.white,
            body: Form(
                child: Stack(children: [
              Expanded(
                  child: Container(
                      child: SafeArea(
                          child: Column(children: [
                Padding(
                  padding: const EdgeInsets.all(28.0),
                  child: Image.asset('images/logo-icon-3.png'),
                ),
                SizedBox(height: 15),
                Text("Sign In",
                    style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
                SizedBox(height: 15),
                Text('Sign In to your account'),
                SizedBox(height: 25),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        fillColor: Colors.white,
                        filled: true,
                        hintText: "Email",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5))),
                  ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        fillColor: Colors.white,
                        filled: true,
                        hintText: "Password",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5))),
                  ),
                ),
                SizedBox(height: 20),
                Row(children: [
                  SizedBox(width: 10),
                  FlutterSwitch(
                    activeColor: Colors.purple,
                    width: 75.0,
                    height: 25.0,
                    valueFontSize: 25.0,
                    toggleSize: 45.0,
                    value: status,
                    borderRadius: 30.0,
                    padding: 8.0,
                    showOnOff: false,
                    onToggle: (val) {
                      setState(() {
                        status = val;
                      });
                    },
                  ),
                  SizedBox(width: 10),
                  Text("Remember Me"),
                  SizedBox(height: 15),
                  // borderRadius:BorderRadius.all(10.0))
                ]),
                SizedBox(height: 5),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 200, right: 0, top: 4, bottom: 4),
                  child: MaterialButton(
                      child: Text("Forgot Password?",
                          style: TextStyle(
                            fontSize: 13,
                            color: Colors.pink,
                          )),
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (BuildContext context) {
                            return forget();
                          }),
                        );
                      }),
                ),
                SizedBox(height: 15),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return const dashboard();
                      }),
                    );
                  },
                  child: Text(
                    "Sign In",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                  style: TextButton.styleFrom(
                      backgroundColor: Colors.pink,
                      padding: EdgeInsets.fromLTRB(150, 15, 150, 15),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5)))

                      // borderRadius:BorderRadius.all(10.0))
                      ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 5, right: 25, bottom: 5),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 70, top: 5, right: 0, bottom: 5),
                        child: Text("Don't have an account?"),
                      ),
                      SizedBox(width: 0),
                      MaterialButton(
                          child: Text("Sign up",
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.pink,
                              )),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return Signup();
                              }),
                            );
                          })
                    ],
                  ),
                ),
              ]))))
            ]))));
  }
}
