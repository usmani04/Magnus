import 'package:flutter/material.dart';
import 'package:magnas_app/Dashboard.dart';

class MainDrawer extends StatefulWidget {
  @override
  _MainDrawerState createState() => _MainDrawerState();
}

class _MainDrawerState extends State<MainDrawer> {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        child: Padding(
          padding: EdgeInsets.only(top: 50.0),
          child: Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(
                  height: 20,
                  width: 310,
                  child: Divider(
                    color: Colors.grey,
                    thickness: 1,
                    indent: 0,
                    endIndent: 0,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
      SizedBox(
        height: 2,
      ),
      //Now let's Add the button for the Menu
      //and let's copy that and modify it
      Container(
        child: ListTile(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (BuildContext context) {
                return dashboard();
              }),
            );
          },
          leading: Icon(
            Icons.home,
            color: Colors.black87,
          ),
          title: Text(
            "Dashboard",
            style: TextStyle(
              fontSize: 17.0,
              fontWeight: FontWeight.w800,
              color: Colors.black87,
            ),
          ),
        ),
      ),

      Container(
        child: ListTile(
          onTap: () {
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (BuildContext context) {
            //     return dashboard();
            //   }),
            // );
          },
          leading: Icon(
            Icons.date_range_rounded,
            color: Colors.black87,
          ),
          title: Text(
            "Records",
            style: TextStyle(
              fontSize: 17.0,
              fontWeight: FontWeight.w800,
              color: Colors.black87,
            ),
          ),
        ),
      ),

      Container(
        child: ListTile(
          onTap: () {
            // Navigator.push(
            //   context,
            //   MaterialPageRoute(builder: (BuildContext context) {
            //     return Earn();
            //   }),
            // );
          },
          leading: Icon(
            Icons.person_pin,
            color: Colors.black87,
          ),
          title: Text(
            "Need Help",
            style: TextStyle(
              fontSize: 17.0,
              fontWeight: FontWeight.w800,
              color: Colors.black87,
            ),
          ),
        ),
      ),
    ]);
  }
}
