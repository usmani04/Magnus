import 'package:flutter/material.dart';

import 'package:magnas_app/signin.dart';
import 'package:magnas_app/signup.dart';

class forget extends StatefulWidget {
  const forget({Key? key}) : super(key: key);

  @override
  State<forget> createState() => _forgetState();
}

class _forgetState extends State<forget> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
            resizeToAvoidBottomInset: false,
            backgroundColor: Colors.white,
            body: Form(
                child: Stack(children: [
              Expanded(
                  child: Container(
                      child: SafeArea(
                          child: Column(children: [
                Padding(
                  padding: const EdgeInsets.all(28.0),
                  child: Image.asset('images/logo-icon-3.png'),
                ),
                SizedBox(height: 15),
                Text("Sign In",
                    style: TextStyle(
                        fontSize: 23,
                        fontWeight: FontWeight.bold,
                        color: Colors.black)),
                SizedBox(height: 15),
                Text('Sign In to your account'),
                SizedBox(height: 25),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextFormField(
                    decoration: InputDecoration(
                        fillColor: Colors.white,
                        filled: true,
                        hintText: "Email",
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(5))),
                  ),
                ),
                SizedBox(height: 10),
                TextButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (BuildContext context) {
                        return const Signin();
                      }),
                    );
                  },
                  child: Text(
                    "Send Email",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 15,
                    ),
                  ),
                  style: TextButton.styleFrom(
                      backgroundColor: Colors.pink,
                      padding: EdgeInsets.fromLTRB(135, 15, 135, 15),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.all(Radius.circular(5)))

                      // borderRadius:BorderRadius.all(10.0))
                      ),
                ),
                SizedBox(height: 10),
                Padding(
                  padding: const EdgeInsets.only(
                      left: 0, top: 5, right: 25, bottom: 5),
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 70, top: 5, right: 0, bottom: 5),
                        child: Text("Don't have an account?"),
                      ),
                      SizedBox(width: 0),
                      MaterialButton(
                          child: Text("Sign up",
                              style: TextStyle(
                                fontSize: 13,
                                color: Colors.pink,
                              )),
                          onPressed: () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (BuildContext context) {
                                return const Signup();
                              }),
                            );
                          })
                    ],
                  ),
                ),
              ]))))
            ]))));
  }
}
