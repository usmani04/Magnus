import 'dart:io';
import 'dart:math';

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:magnas_app/MainDrawer.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:file_picker/file_picker.dart';

class dashboard extends StatefulWidget {
  const dashboard({Key? key}) : super(key: key);

  @override
  State<dashboard> createState() => _dashboardState();
}

class _dashboardState extends State<dashboard> {
  void startCreatingData() async {
    for (int i = 0; i < 12; i++) {
      if (i == 0) continue;
      await Future.delayed((Duration(seconds: 1))).then((value) {
        Random random = Random();
        flspots.add(FlSpot(
          double.parse(i.toString()),
          random.nextDouble() * 6,
        ));
        setState(() {
          setChartData();
        });
      });
    }
  }

  LineChartData data = LineChartData();
  void setChartData() {
    data = LineChartData(
        gridData: FlGridData(
            show: false,
            drawVerticalLine: false,
            getDrawingHorizontalLine: (value) {
              return FlLine(color: Color(0xff37434d), strokeWidth: 1);
            },
            getDrawingVerticalLine: (value) {
              return FlLine(color: Color(0xff37434d), strokeWidth: 1);
            }),
        titlesData: FlTitlesData(
          show: false,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              interval: 1,
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              interval: 1,
              reservedSize: 42,
            ),
          ),
        ),
        borderData: FlBorderData(
            show: false,
            border: Border.all(color: Color(0xff37434d), width: 1)),
        minX: 0,
        maxX: 11,
        minY: 0,
        maxY: 6,
        lineBarsData: [
          LineChartBarData(
            spots: flspots,
            isCurved: true,
            color: Colors.black,
            barWidth: 5,
            isStrokeCapRound: true,
            dotData: FlDotData(show: false),
            belowBarData: BarAreaData(show: true, color: Colors.red),
          )
        ]);
  }

  List<FlSpot> flspots = [FlSpot(0, 0)];
  // List<Color> gradientColors = [
  //   const Color(0xff23b6e6),
  //   const Color(0xff02d39a)
  // ];

  @override
  void initState() {
    super.initState();
    setChartData();
    startCreatingData();
  }

  final emailController = TextEditingController();
  TextEditingController dateCtl = TextEditingController();
  String? valueChoose;

  // List of items in our dropdown menu
  var items = ["RoDTEP", "RoSCTL", "MEIS", "OTHER"];
  File? profile;
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        child: Scaffold(
          appBar: PreferredSize(
            preferredSize: const Size.fromHeight(60.0),
            child: AppBar(
              backgroundColor: Colors.grey[300],
              elevation: 0,
              actions: [
                IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.search, color: Colors.black)),
                IconButton(
                    onPressed: () {},
                    icon: Icon(Icons.notifications, color: Colors.black)),
                CircleAvatar(
                  backgroundColor: Colors.transparent,
                  // radius: 25.0,
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    radius: 18.0,
                    child: CircleAvatar(
                      radius: 20.0,
                      backgroundImage: NetworkImage(
                        "https://images.unsplash.com/photo-1594616838951-c155f8d978a0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1050&q=80",
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
          drawer: Drawer(
            backgroundColor: Colors.black,
            child: Container(
              color: Colors.white,
              child: MainDrawer(),
            ),
          ),
          body: Form(
            child: SingleChildScrollView(
              child: Container(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          height: 150,
                          width: 500,
                          clipBehavior: Clip.hardEdge,
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(0, 0),
                                    color: Colors.grey.withOpacity(0.23)),
                              ]),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Icon(Icons.subject_sharp,
                                        color: Colors.black, size: 30),
                                  ),
                                  Text(
                                    "Submitted",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 19),
                                  ),
                                  SizedBox(
                                    width: 190,
                                  ),
                                  Icon(
                                    Icons.more_horiz,
                                    color: Colors.black,
                                    size: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.all(20),
                                    child: Text(
                                      "2",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 20),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 170,
                                  ),
                                  Container(
                                    height:
                                        MediaQuery.of(context).size.height * .1,
                                    width:
                                        MediaQuery.of(context).size.width * .3,
                                    child: LineChart(data),
                                  )
                                ],
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          height: 150,
                          width: 500,
                          clipBehavior: Clip.hardEdge,
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(0, 0),
                                    color: Colors.grey.withOpacity(0.23)),
                              ]),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Icon(Icons.pending_actions,
                                        color: Colors.black, size: 30),
                                  ),
                                  Text(
                                    "Pending",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 19),
                                  ),
                                  SizedBox(
                                    width: 190,
                                  ),
                                  Icon(
                                    Icons.more_horiz,
                                    color: Colors.black,
                                    size: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.all(20),
                                    child: Text(
                                      "2",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 20),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 170,
                                  ),
                                  Container(
                                    height:
                                        MediaQuery.of(context).size.height * .1,
                                    width:
                                        MediaQuery.of(context).size.width * .3,
                                    child: LineChart(data),
                                  )
                                ],
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          height: 150,
                          width: 500,
                          clipBehavior: Clip.hardEdge,
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(0, 0),
                                    color: Colors.grey.withOpacity(0.23)),
                              ]),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Icon(Icons.verified,
                                        color: Colors.black, size: 30),
                                  ),
                                  Text(
                                    "Verified",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 19),
                                  ),
                                  SizedBox(
                                    width: 190,
                                  ),
                                  Icon(
                                    Icons.more_horiz,
                                    color: Colors.black,
                                    size: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.all(20),
                                    child: Text(
                                      "2",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 20),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 170,
                                  ),
                                  Container(
                                    height:
                                        MediaQuery.of(context).size.height * .1,
                                    width:
                                        MediaQuery.of(context).size.width * .3,
                                    child: LineChart(data),
                                  )
                                ],
                              ),
                            ],
                          )),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          height: 150,
                          width: 500,
                          clipBehavior: Clip.hardEdge,
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(0, 0),
                                    color: Colors.grey.withOpacity(0.23)),
                              ]),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.all(15.0),
                                    child: Icon(Icons.cancel,
                                        color: Colors.black, size: 30),
                                  ),
                                  Text(
                                    "cancelled",
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 19),
                                  ),
                                  SizedBox(
                                    width: 190,
                                  ),
                                  Icon(
                                    Icons.more_horiz,
                                    color: Colors.black,
                                    size: 30,
                                  ),
                                ],
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              Row(
                                children: [
                                  Container(
                                    margin: const EdgeInsets.all(20),
                                    child: Text(
                                      "2",
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 20),
                                    ),
                                  ),
                                  SizedBox(
                                    width: 170,
                                  ),
                                  Container(
                                    height:
                                        MediaQuery.of(context).size.height * .1,
                                    width:
                                        MediaQuery.of(context).size.width * .3,
                                    child: LineChart(data),
                                  )
                                ],
                              ),
                            ],
                          )),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                          height: 750,
                          width: 500,
                          clipBehavior: Clip.hardEdge,
                          margin: EdgeInsets.symmetric(vertical: 10),
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: Colors.white,
                              boxShadow: [
                                BoxShadow(
                                    offset: const Offset(0, 0),
                                    color: Colors.grey.withOpacity(0.23)),
                              ]),
                          child: Column(
                            children: [
                              Container(
                                margin: const EdgeInsets.all(20),
                                child: Text(
                                  "SCRIP FORM",
                                  style: TextStyle(fontSize: 20),
                                ),
                              ),
                              Container(
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Container(
                                    padding:
                                        EdgeInsets.only(left: 16, right: 16),
                                    decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.grey, width: 1),
                                        borderRadius: BorderRadius.circular(5)),
                                    child: DropdownButton(
                                      hint: Text("Please Select"),

                                      // Initial Value
                                      value: valueChoose,

                                      // Down Arrow Icon
                                      icon: const Icon(Icons.arrow_drop_down),
                                      iconSize: 36,
                                      isExpanded: true,
                                      underline: SizedBox(),
                                      style: TextStyle(
                                          color: Colors.black, fontSize: 22),

                                      // Array list of items
                                      items: items.map((String items) {
                                        return DropdownMenuItem(
                                          value: items,
                                          child: Text(items),
                                        );
                                      }).toList(),
                                      // After selecting the desired option,it will
                                      // change button value to selected value
                                      onChanged: (String? newValue) {
                                        setState(() {
                                          valueChoose = newValue!;
                                        });
                                      },
                                    ),
                                  ),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 16, right: 16),
                                margin: EdgeInsets.symmetric(vertical: 8.0),
                                child: TextFormField(
                                  autofocus: false,
                                  decoration: InputDecoration(
                                    hintText: 'Scrip Number: ',
                                    hintStyle: TextStyle(fontSize: 20.0),
                                    border: OutlineInputBorder(),
                                    errorStyle: TextStyle(
                                        color: Colors.redAccent, fontSize: 15),
                                  ),
                                  controller: emailController,
                                  // validator: (value) {
                                  //   if (value == null || value.isEmpty) {
                                  //     return 'Please Enter Email';
                                  //   } else if (!value.contains('@')) {
                                  //     return 'Please Enter Valid Email';
                                  //   }
                                  //   return null;
                                  // },
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 16, right: 16),
                                margin: EdgeInsets.symmetric(vertical: 8.0),
                                child: TextFormField(
                                  autofocus: false,
                                  decoration: InputDecoration(
                                    hintText: 'mm/dd/yy: ',
                                    hintStyle: TextStyle(fontSize: 20.0),
                                    border: OutlineInputBorder(),
                                    errorStyle: TextStyle(
                                        color: Colors.redAccent, fontSize: 15),
                                  ),
                                  controller: dateCtl,
                                  onTap: () async {
                                    DateTime? date = DateTime(1900);
                                    FocusScope.of(context)
                                        .requestFocus(new FocusNode());

                                    date = (await showDatePicker(
                                        context: context,
                                        initialDate: DateTime.now(),
                                        firstDate: DateTime(1900),
                                        lastDate: DateTime(2100)));

                                    dateCtl.text = date!.toIso8601String();
                                  },
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 16, right: 16),
                                margin: EdgeInsets.symmetric(vertical: 8.0),
                                child: TextFormField(
                                  autofocus: false,
                                  decoration: InputDecoration(
                                    hintText: 'Scrip Amount: ',
                                    hintStyle: TextStyle(fontSize: 20.0),
                                    border: OutlineInputBorder(),
                                    errorStyle: TextStyle(
                                        color: Colors.redAccent, fontSize: 15),
                                  ),
                                  controller: emailController,
                                  // validator: (value) {
                                  //   if (value == null || value.isEmpty) {
                                  //     return 'Please Enter Email';
                                  //   } else if (!value.contains('@')) {
                                  //     return 'Please Enter Valid Email';
                                  //   }
                                  //   return null;
                                  // },
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.only(left: 16, right: 16),
                                margin: EdgeInsets.symmetric(vertical: 8.0),
                                child: TextFormField(
                                  autofocus: false,
                                  decoration: InputDecoration(
                                    hintText: 'Portal Code: ',
                                    hintStyle: TextStyle(fontSize: 20.0),
                                    border: OutlineInputBorder(),
                                    errorStyle: TextStyle(
                                        color: Colors.redAccent, fontSize: 15),
                                  ),
                                  controller: emailController,
                                  // validator: (value) {
                                  //   if (value == null || value.isEmpty) {
                                  //     return 'Please Enter Email';
                                  //   } else if (!value.contains('@')) {
                                  //     return 'Please Enter Valid Email';
                                  //   }
                                  //   return null;
                                  // },
                                ),
                              ),
                              InkWell(
                                child: Container(
                                  padding: EdgeInsets.only(left: 16, right: 16),
                                  margin: EdgeInsets.symmetric(vertical: 8.0),
                                  child: TextFormField(
                                    autofocus: false,
                                    decoration: InputDecoration(
                                      hintText: 'choose File: ',
                                      hintStyle: TextStyle(fontSize: 20.0),
                                      border: OutlineInputBorder(),
                                      errorStyle: TextStyle(
                                          color: Colors.redAccent,
                                          fontSize: 15),
                                    ),
                                    // controller: emailController,
                                    // validator: (value) {
                                    //   if (value == null || value.isEmpty) {
                                    //     return 'Please Enter Email';
                                    //   } else if (!value.contains('@')) {
                                    //     return 'Please Enter Valid Email';
                                    //   }
                                    //   return null;
                                    // },
                                    onTap: () async {
                                      final result =
                                          await FilePicker.platform.pickFiles(
                                        type: FileType.custom,
                                        allowedExtensions: [
                                          'jpg',
                                          'pdf',
                                          'doc'
                                        ],
                                      );
                                      if (result != null) {
                                        final path = result.files.single.path!;
                                        setState(() {
                                          profile = File(path);
                                        });
                                      } else {
                                        // User canceled the picker
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ],
                          )),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
